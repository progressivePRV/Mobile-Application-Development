package com.example.inclass11;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.style.UpdateAppearance;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;

import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;

public class EditExpense extends AppCompatActivity {

    private static final String TAG = "chupbes";
    static String[] categories = {"Groceries", "Invoice", "Transportation", "Shopping", "Rent", "Trips", "Utilities", "Other"};
    Expense ex;
    String docId;

    HashMap<String ,Object> update = new HashMap<>();
    String category;
    Spinner spinCategory;
    EditText etExpName, etAmount;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_expense);

        setTitle("Edit Expense");
        docId=getIntent().getExtras().getString("docId");
        ex = (Expense) getIntent().getExtras().getSerializable("ex");
        db = FirebaseFirestore.getInstance();

        etAmount = findViewById(R.id.et_amount_inEditExpense);
        etExpName = findViewById(R.id.et_expense_name_inEditExpense);
        etAmount.setText(""+ex.cost);
        etExpName.setText(ex.title);
        spinCategory = findViewById(R.id.spinner_category_inEditExpense);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinCategory.setAdapter(adapter);

        spinCategory.setSelection(IndexOfInStringArray(categories, ex.category));
        //
        spinCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                category = categories[position];
                Log.d(TAG, "onItemSelected: category"+category);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        findViewById(R.id.btn_cancel_inEditExpense).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        findViewById(R.id.btn_save_inEditExpense).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkValidation() && checkForChange()) {
                    Log.d(TAG, "onClick: update="+update);
                    Log.d(TAG, "onClick: docId"+docId);
                    db.collection("Expenses").document(docId)
                            .update(update)
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.d(TAG, "onFailure: in update");
                                }
                            })
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Log.d(TAG, "onSuccess: in update");
                                }
                            });
                    finish();
                }
            }
        });

    }

    boolean checkValidation(){
        Log.d(TAG, "checkValidation: called in edit Expense");
        if (etExpName.getText().toString().equals("")){
            etExpName.setError("should not be empty");
            return false;
        }
        if (etAmount.getText().toString().equals("")){
            etAmount.setError("should not be empty");
            return false;
        }else{
            Double d = Double.valueOf(etAmount.getText().toString());
            if (d==0.0){
                etAmount.setError("should not be Zero");
                return false;
            }
        }
        Log.d(TAG, "checkValidation: return true");
        return true;
    }

    int IndexOfInStringArray(String[] strArr, String str) {
        int i = 0;
        for (; i < strArr.length; i++) {
            String s = strArr[i];
            if (s.equals(str)) {
                return i;
            }
        }
        return i;
    }

    boolean checkForChange() {
        boolean check=false;
        Log.d(TAG, "checkForChange: called in edit expense");
        if (!ex.title.equals(etExpName.getText().toString())) {
            update.put("title",etExpName.getText().toString());
            check=true;
        }
        if (ex.cost!=Double.valueOf(etAmount.getText().toString())) {
            Log.d(TAG, "checkForChange: cost in expense"+ex.cost);
            Log.d(TAG, "checkForChange: cost in et"+Double.valueOf(etAmount.getText().toString()));
            update.put("cost",Double.valueOf(etAmount.getText().toString()));
            check=true;
        }
        if (!ex.category.equals(category)) {
            Log.d(TAG, "checkForChange: in category if");
            update.put("category",category);
            check=true;
        }
        return check;
    }
}
