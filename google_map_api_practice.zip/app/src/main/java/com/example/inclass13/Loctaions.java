package com.example.inclass13;

import android.text.style.AlignmentSpan;

import java.util.List;

public class Loctaions {
    List<Location> points;
    String title;

    public Loctaions(List<Location> points, String title) {
        this.points = points;
        this.title = title;
    }

    @Override
    public String toString() {
        return "Loctaions{" +
                "points=" + points +
                ", title='" + title + '\'' +
                '}';
    }

    public List<Location> getPoints() {
        return points;
    }

    public String getTitle() {
        return title;
    }

    public void setPoints(List<Location> points) {
        this.points = points;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
