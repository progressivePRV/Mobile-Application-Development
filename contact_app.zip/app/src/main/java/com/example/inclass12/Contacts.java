package com.example.inclass12;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class Contacts extends AppCompatActivity implements MyAdapter.ToCommunicateWithAcitivity {

    private static final String TAG = "chupbes";
    String uid;
    FirebaseFirestore db;
    RecyclerView rV;
    RecyclerView.Adapter rvAdapter;
    RecyclerView.LayoutManager layoutManager;
    ArrayList<ContactsObj> contacts = new ArrayList<>();
    ArrayList<String> docIds =  new ArrayList<>();
    DocumentReference docRef;
    FirebaseStorage storage;
    StorageReference storageRef;
    ProgressBar pb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts);

        setTitle("Contacts");

        if (!isConnected()){
            Toast.makeText(this, "There is NO Internet Connection, Application may not work properly", Toast.LENGTH_LONG).show();
        }


        storage = FirebaseStorage.getInstance();
        storageRef=storage.getReference();
        db = FirebaseFirestore.getInstance();
        uid=getIntent().getExtras().getString("uid");
        docRef = db.collection("Users").document(uid);

        pb=findViewById(R.id.pb_inContacts);

        AttachOnSnapShotListener();
        rV = findViewById(R.id.rv_inContacts);
        rV.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        rV.setLayoutManager(layoutManager);
        rvAdapter = new MyAdapter(contacts,this);
        rV.setAdapter(rvAdapter);


        findViewById(R.id.btn_create_new_contact_inContacts).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Contacts.this,CreateNewContact.class);
                i.putExtra("uid",uid);
                startActivity(i);
            }
        });

        findViewById(R.id.iv_logout_inContacts).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dologout();
            }
        });
    }


    private void AttachOnSnapShotListener() {
        pb.setVisibility(View.VISIBLE);
        docRef.collection("Contacts")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                        if (e != null) {
                            Log.w(TAG, "listen:error", e);
                            return;
                        }

                        for (DocumentChange dc : queryDocumentSnapshots.getDocumentChanges()) {
                            switch (dc.getType()) {
                                case ADDED:
                                    Log.d(TAG, "New ContactAdded: " + dc.getDocument().getData());
                                    ContactsObj c = dc.getDocument().toObject(ContactsObj.class);
                                    Log.d(TAG, "onEvent: email="+c.email);
                                    Log.d(TAG, "onEvent: name="+c.name);
                                    Log.d(TAG, "onEvent: phone="+c.phone);
                                    Log.d(TAG, "onEvent: photourl="+c.photoUrl);
                                    contacts.add(c);
                                    docIds.add(dc.getDocument().getId());
                                    break;
                                case MODIFIED:
                                    Log.d(TAG, "Modified Contact: " + dc.getDocument().getData());
                                    break;
                                case REMOVED:
                                    Log.d(TAG, "Removed Contact: " + dc.getDocument().getData());
                                    break;
                            }
                        }
                        pb.setVisibility(View.INVISIBLE);
                        rvAdapter.notifyDataSetChanged();
                    }
                });
    }

    private void dologout() {
        FirebaseAuth.getInstance().signOut();
        Intent i = new Intent(Contacts.this,MainActivity.class);
        startActivity(i);
        finish();
    }

    @Override
    public void deleteContact(int postion) {
        deleteFromDBSuccessful(postion);
    }

    private void DeleteImageFromStorage(int x) {
        if (contacts.get(x).photoName.equals("Nope")){
            Log.d(TAG, "DeleteImageFromStorage: there was no photo to delete");
            return;
        }
        storageRef.child(contacts.get(x).photoName)
                .delete()
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()){
                            Log.d(TAG, "onComplete: photo got deleted from storage");
                        }else{
                            Log.d(TAG, "onComplete: error in deleting the photo from storage");
                        }
                    }
                });
    }

    private void deleteFromDBSuccessful(final int i) {
        String docId = docIds.get(i);
        docRef.collection("Contacts").document(docId)
                .delete()
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                            Log.d(TAG, "onComplete succesful in delete contact: ");
                            Toast.makeText(Contacts.this, "Contact Deleted", Toast.LENGTH_SHORT).show();
                            DeleteImageFromStorage(i);
                            contacts.remove(i);
                            docIds.remove(i);
                            rvAdapter.notifyDataSetChanged();
                            Log.d(TAG, "onComplete: cout of contacts:"+contacts.size());
                        }else{
                            Log.d(TAG, "onComplete: faliur in delete Contact");
                            Toast.makeText(Contacts.this, "Can't delete", Toast.LENGTH_SHORT).show();

                        }
                    }
                });
    }
    boolean isConnected(){
        ConnectivityManager cm = (ConnectivityManager)this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
        return isConnected;
    }
}
