package com.example.inclass10;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;


public class SelectAvatar extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    ToEditFromSelectAvatar toEditFromSelectAvatar;

    public SelectAvatar() {
        // Required empty public constructor
    }

    private ImageView ivMale,ivFemale;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        toEditFromSelectAvatar = (ToEditFromSelectAvatar) getActivity();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_select_avatar, container, false);

        getActivity().setTitle("Select Avatar");

        ivFemale = view.findViewById(R.id.iv_female_inSelectAvatar);
        ivMale = view.findViewById(R.id.iv_male_inSelectAvatar);
        ivFemale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toEditFromSelectAvatar.updateAatar(true);
            }
        });

        ivMale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toEditFromSelectAvatar.updateAatar(false);
            }
        });

        return view;
    }

    public interface ToEditFromSelectAvatar{
        void updateAatar(boolean isFemale);
    }
}
