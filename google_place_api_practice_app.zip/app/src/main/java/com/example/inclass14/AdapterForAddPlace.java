package com.example.inclass14;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;


public class AdapterForAddPlace extends RecyclerView.Adapter<AdapterForAddPlace.ViewHolder> {

    TointeractWithAddPlaces t;
    Context ctx;
    ArrayList<Place> places =  new ArrayList<>();
    public AdapterForAddPlace(ArrayList<Place> arrayList,AddPlaces addPlaces) {
        super();
        this.places = arrayList;
        this.ctx = addPlaces;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LinearLayout layout = (LinearLayout) LayoutInflater.from(parent.getContext()).inflate(R.layout.rv_for_add_places,parent,false);
        ViewHolder viewHolder = new ViewHolder(layout);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        t= (TointeractWithAddPlaces) ctx;
        Picasso.get().load(places.get(position).icon).into(holder.ivIcon);
        holder.tvPlace.setText(places.get(position).name);
        holder.ivAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t.addPlace(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return places.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvPlace;
        ImageView ivIcon,ivAdd;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvPlace = itemView.findViewById(R.id.tv_placeName_inRvinAddPlaces);
            ivAdd = itemView.findViewById(R.id.iv_add_inRvinAddPlaces);
            ivIcon = itemView.findViewById(R.id.ivIcon_inRvinAddPlaces);
        }
    }

    interface TointeractWithAddPlaces {
        void addPlace(int x);
    }
}
