package com.example.inclass07_2;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    static final String dataKey = "dataKey";

    static ArrayList<Questions> GlobalQuestions;
    static ImageView ivTrivia;
    static ProgressBar pb1;
    static Button btnStartTrivia;
    static TextView tvTriviaReady;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ivTrivia = findViewById(R.id.ivTrivia);
        pb1 = findViewById(R.id.pb1);
        if (isConnected()){
            new GetQuestions().execute();
        }
        tvTriviaReady = findViewById(R.id.tvTriviaRaedy);
        btnStartTrivia = findViewById(R.id.btnStartTrivia);

        btnStartTrivia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =  new Intent(MainActivity.this, TriviaActivity.class);
                i.putExtra(dataKey,GlobalQuestions);
                startActivity(i);
            }
        });

        findViewById(R.id.btnExit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }

    private static class GetQuestions extends AsyncTask<Void, Void, ArrayList<Questions>> {

        ArrayList<Questions> questions;


        @Override
        protected ArrayList<Questions> doInBackground(Void... voids) {
            HttpURLConnection connection = null;
            questions = new ArrayList<Questions>();
            try {
                URL url = new URL("http://dev.theappsdr.com/apis/trivia_json/index.php");
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    String json = IOUtils.toString(connection.getInputStream(), "UTF8");

                    JSONObject root = new JSONObject(json);
                    JSONArray ques = root.getJSONArray("questions");

                    for (int i=0;i<ques.length();i++){
                        JSONObject que = ques.getJSONObject(i);
                        Questions q = new Questions();
                        q.id = Integer.valueOf(que.getString("id"));
                        q.txtQue = que.getString("text");
                        try {
                            q.ImageUrl = que.getString("image");
                        }catch (Exception e){
                            q.ImageUrl = null;
                        }
                        JSONObject temp =  que.getJSONObject("choices");
                        JSONArray arrJson = temp.getJSONArray("choice");
                        String[] arr = new String[arrJson.length()];
                        for(int x = 0; x < arrJson.length(); x++)
                            arr[x] = arrJson.getString(x);
                        q.choices = arr;
                        q.ans = Integer.valueOf(temp.getString("answer"));

                        questions.add(q);
                        //Log.d("trythis", String.valueOf(q));
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return questions;
        }

        @Override
        protected void onPostExecute(ArrayList<Questions> questions) {
            super.onPostExecute(questions);
            Log.d("trythis",questions.toString());
            GlobalQuestions = questions;
            pb1.setVisibility(View.INVISIBLE);
            tvTriviaReady.setVisibility(View.VISIBLE);
            ivTrivia.setVisibility(View.VISIBLE);
            btnStartTrivia.setClickable(true);
        }
    }
}

