package com.example.inclass07_2;

import android.net.Uri;

import androidx.annotation.NonNull;

import java.io.Serializable;
import java.net.URL;

public class Questions implements Serializable {
    int id;
    String txtQue,ImageUrl;
    String[] choices;
    int ans;

    @NonNull
    @Override
    public String toString() {
        return "id ="+id+"\n url="+ImageUrl+"\n"
                +"ch="+choices[0]+"\n";
    }

}
