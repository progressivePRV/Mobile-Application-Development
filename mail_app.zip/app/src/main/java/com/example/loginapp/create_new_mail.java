package com.example.loginapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.FormBody;
import okhttp3.Headers;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class create_new_mail extends AppCompatActivity{

    Spinner spin1;
    static final String TAG="chup1";
    EditText etContent,etSubject;
    SharedPreferences sp;
    String token;
    JSONArray users;
    ArrayList<String> usersNames = new ArrayList<>();
    ArrayAdapter<String> dataAdapter;
    String receiverId="",subject,message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_new_mail);

        etContent = findViewById(R.id.et_email_content);
        etSubject = findViewById(R.id.et_subject);
        sp = this.getSharedPreferences(getResources().getString(R.string.SharedPrefrence_File),MODE_PRIVATE);
        spin1 = findViewById(R.id.spinner);
        spin1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Log.d(TAG, "onItemSelected: item no.="+(position-1));
                if (position!=0){
                    try {
                        JSONObject u = users.getJSONObject((position-1));
                        Log.d(TAG, "onItemSelected: user id ="+u.getString("id"));
                        receiverId = u.getString("id");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }else{
                    receiverId="";
                    Toast.makeText(create_new_mail.this, "select user to send mail", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        findViewById(R.id.btn_sent_increateEmail).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (receiverId.equals("")){
                    Toast.makeText(create_new_mail.this, "select user to send mail", Toast.LENGTH_SHORT).show();
                }else if (etSubject.getText().toString().equals("")){
                    etSubject.setError("this should not be empty");
                }else if (etContent.getText().toString().equals("")){
                    etContent.setError("this should not be empty");
                }else {
                    subject = etSubject.getText().toString();
                    message = etContent.getText().toString();
                    new sendMail().execute(receiverId,subject,message,token);
                }
            }
        });

        findViewById(R.id.btn_cancel_increateEmail).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        token = sp.getString("token","shouldHaveToken");
        new getUser().execute(token);
    }
    

    class sendMail extends AsyncTask<String ,Void,String >{

        String receiverID,subject,message,result;

        @Override
        protected String doInBackground(String... str) {
            receiverID=str[0];
            subject=str[1];
            message=str[2];
            final OkHttpClient client = new OkHttpClient();
            RequestBody formBody = new FormBody.Builder()
                    .add("receiver_id", receiverID)
                    .add("subject", subject)
                    .add("message", message)
                    .build();
            Request request = new Request.Builder()
                    .url("http://ec2-18-234-222-229.compute-1.amazonaws.com/api/inbox/add")
                    .header("Authorization", "BEARER "+str[3])
                    .header("Content-Type","application/x-www-form-urlencoded")
                    .post(formBody)
                    .build();
            try {
                Response response = client.newCall(request).execute();
                if (!response.isSuccessful()) {
                    //throw new IOException("Unexpected code " + response);
                    result = response.body().string();
                } else {
                    Headers responseHeaders = response.headers();
                    for (int i = 0; i < responseHeaders.size(); i++) {
                        System.out.println(responseHeaders.name(i) + ": " + responseHeaders.value(i));
                    }
                    result = response.body().string();
                    Log.d(TAG, "doInBackground: result from send mail :" + result);
                }
                return result;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            String status = null;
            JSONObject r = null;
            try {
                r = new JSONObject(s);
                status = r.getString("status");
                switch (status){
                    case "error":
                        Toast.makeText(create_new_mail.this, r.getString("message"), Toast.LENGTH_SHORT).show();
                        break;
                    case "ok":
                        Toast.makeText(create_new_mail.this, "Mail Sent", Toast.LENGTH_SHORT).show();
                        create_new_mail.this.finish();
                        break;
                    default:
                        Toast.makeText(create_new_mail.this, "Unable to send mail", Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    class getUser extends AsyncTask<String ,Void,String >{

        String result;
        @Override
        protected String doInBackground(String... str) {
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url("http://ec2-18-234-222-229.compute-1.amazonaws.com/api/users")
                    .header("Authorization", "BEARER "+str[0])
                    .build();

            try {
                Response response = client.newCall(request).execute();
                if (!response.isSuccessful()){
                    result=response.body().string();
                }else{
                    System.out.println("Server: " + response.header("Server"));
                    System.out.println("Date: " + response.header("Date"));
                    System.out.println("Vary: " + response.headers("Vary"));
                    result = response.body().string();
                    Log.d(TAG, "doInBackground: in get users result "+result);
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            PareceJsonUsers(s);
        }
    }

    private void PareceJsonUsers(String s) {
        JSONObject user;
        String name;
        name = "Select User";
        usersNames.add(name);
        try {
            JSONObject root =  new JSONObject(s);
            users = root.getJSONArray("users");
            Log.d(TAG, "PareceJsonUsers: no. of users="+users.length());
            for(int i=0;i<users.length();i++){
                user = users.getJSONObject(i);
                name = user.getString("fname")+" "+user.getString("lname");
                usersNames.add(name);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        // addind into spinner
        dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, usersNames);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin1.setAdapter(dataAdapter);

    }
}
