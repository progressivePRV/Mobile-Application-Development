package com.example.inclass14;

import java.io.Serializable;
import java.util.ArrayList;

public class CityObjInfo implements Serializable {
    String CityName,TripName,place_id,doc_ref;
    Double lat,lng;
    ArrayList<Place> places = new ArrayList<>();

    public CityObjInfo(String cityName, String tripName, Double lat, Double lng,ArrayList<Place> places,String doc_ref) {
        CityName = cityName;
        TripName = tripName;
        this.lat = lat;
        this.lng = lng;
        this.places = places;
        this.doc_ref = doc_ref;
    }

    public CityObjInfo() {
    }


    @Override
    public String toString() {
        return "CityObjInfo{" +
                "CityName='" + CityName + '\'' +
                ", TripName='" + TripName + '\'' +
                ", lat='" + lat + '\'' +
                ", lng='" + lng + '\'' +
                ", place_id='" + place_id + '\'' +
                ", doc_ref='" + doc_ref + '\'' +
                ", places=" + places +
                '}';
    }

    public String getCityName() {
        return CityName;
    }

    public String getTripName() {
        return TripName;
    }

    public Double getLat() {
        return lat;
    }

    public Double getLng() {
        return lng;
    }

    public String getPlace_id() {
        return place_id;
    }

    public ArrayList<Place> getPlaces() {
        return places;
    }
}
