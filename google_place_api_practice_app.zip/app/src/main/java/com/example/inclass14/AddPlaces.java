package com.example.inclass14;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class AddPlaces extends AppCompatActivity implements AdapterForAddPlace.TointeractWithAddPlaces {

    private static final String TAG = "chupbes";
    ArrayList<Place> places = new ArrayList<>();
    String city_doc_ref;
    Double lat, lng;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    RecyclerView rv;
    RecyclerView.Adapter rv_adater;
    RecyclerView.LayoutManager rv_layoutManager;
    String apiKey;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_places);

        apiKey = getResources().getString(R.string.Apikey);
        setTitle("Add Places");

        city_doc_ref = (String) getIntent().getExtras().get("city_doc_ref");
        lat = (Double) getIntent().getExtras().get("lat");
        lng = (Double) getIntent().getExtras().get("lng");

        rv = findViewById(R.id.rv_inAddPlaces);
        rv.setHasFixedSize(true);
        rv_layoutManager = new LinearLayoutManager(this);
        rv.setLayoutManager(rv_layoutManager);
        rv_adater = new AdapterForAddPlace(places,this);
        rv.setAdapter(rv_adater);

        new GetNearByPlaces().execute(lat, lng);

    }

    @Override
    public void addPlace(int x) {
        //store it in fireStore
        db.collection("Trips")
                .document(city_doc_ref)
                .collection("Places")
                .document(places.get(x).placeId)
                .set(places.get(x))
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()){
                            Log.d(TAG, "onComplete: adding place to firestore succeful");
                            finish();
                        }else{
                            Log.d(TAG, "onComplete: adding place to firestore failed");
                        }
                    }
                });
    }

    class GetNearByPlaces extends AsyncTask<Double, Void, String> {

        @Override
        protected String doInBackground(Double... d) {
            String url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?" +
                    "key=" + apiKey + "&" +
                    "location=" + d[0] + "," + d[1] + "&" +//latitude,logitude
                    "radius=1000";
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(url)
                    .build();
            try {
                Response response = client.newCall(request).execute();
                Log.d(TAG, "doInBackground: GetNearByPlaces: response code:" + response.code());
                return response.body().string();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return "";
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (s.equals("")) {
                Toast.makeText(AddPlaces.this, "api return nothing,try again", Toast.LENGTH_SHORT).show();
            } else {
                parseJsonForNearBy(s);
                Log.d(TAG, "onPostExecute: places count:"+places.size());
                rv_adater.notifyDataSetChanged();
            }
        }
    }

    private void parseJsonForNearBy(String s) {
        try {
            JSONObject root = new JSONObject(s);
            String status = root.getString("status");
            Toast.makeText(this, status, Toast.LENGTH_SHORT).show();
            JSONArray results = root.getJSONArray("results");
            for (int i = 1; i < results.length(); i++) {
                JSONObject obj = (JSONObject) results.get(i);
                Place p = new Place();
                JSONObject geometry = obj.getJSONObject("geometry");
                JSONObject location = geometry.getJSONObject("location");
                p.lat = location.getDouble("lat");
                p.lng = location.getDouble("lng");
                p.placeId = obj.getString("place_id");
                p.icon = obj.getString("icon");
                p.name = obj.getString("name");
                places.add(p);
            }
            //Log.d(TAG, "parseJsonForNearBy: plcace="+p);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
