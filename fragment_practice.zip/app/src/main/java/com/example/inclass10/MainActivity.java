package com.example.inclass10;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity implements EditFragment.ToAvatarFromEdit, Display.ToFinishDisplayFrag,SelectAvatar.ToEditFromSelectAvatar {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportFragmentManager().beginTransaction()
                .add(R.id.container_inMainActivity, new EditFragment(),"Edit_fragment")
                .commit();
    }

    @Override
    public void startSelectAvatar() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container_inMainActivity, new SelectAvatar(),"Select_Avatar_fragment")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void startDisplayFrag(String name,String gender) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container_inMainActivity, new Display(name,gender),"Display_fragment")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void onBackPressed() {
        if (getSupportFragmentManager().getBackStackEntryCount()>0){
            getSupportFragmentManager().popBackStack();
        }else{
            super.onBackPressed();
        }
    }

    @Override
    public void updateAatar(boolean isFemale) {
        getSupportFragmentManager().popBackStack();
        EditFragment ef = (EditFragment) getSupportFragmentManager().findFragmentByTag("Edit_fragment");//SetAvatar(isFemale);
        if (isFemale){
            ef.SetAvatar("female");
        }else{
            ef.SetAvatar("male");
        }

    }

    @Override
    public void finishLatestFrag() {
        getSupportFragmentManager().popBackStack();
    }
}
