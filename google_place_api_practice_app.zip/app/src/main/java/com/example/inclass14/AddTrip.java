package com.example.inclass14;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class AddTrip extends AppCompatActivity {

    String apiKey;
    private static final String TAG = "chupbes";
    ArrayList<String> nameOfCityWithState = new ArrayList<>();
    ArrayList<String> placeIds = new ArrayList<>();
    EditText etTripName,etCityName;
    // Access a Cloud Firestore instance from your Activity
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    ArrayAdapter<String> adapter;
    Double lng,lat;
    ListView lv;
    private int selectedCity = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_trip);

        setTitle("Add Trip");
        apiKey=getResources().getString(R.string.Apikey);
        etCityName = findViewById(R.id.et_cityName_inAddTrip);
        etTripName = findViewById(R.id.et_tripName_inAddTrip);
        lv = findViewById(R.id.list_inAddTrip);
        adapter =  new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,android.R.id.text1, nameOfCityWithState);
        lv.setAdapter(adapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                etCityName.setText(nameOfCityWithState.get(position));
                selectedCity = position;
            }
        });

        findViewById(R.id.btn_search_inAddTrip).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                placeIds.clear();
                nameOfCityWithState.clear();
                selectedCity=-1;
                if (etCityName.getText().toString().equals("")){
                    etCityName.setError("give name of city");
                }else {
                    new getFirstApi().execute(etCityName.getText().toString().trim());
                }
            }
        });

        findViewById(R.id.btn_addTrip_inAddTrip).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (etCityName.getText().toString().equals("")){
                    etCityName.setError("give name of city");
                    return;
                }
                if (etTripName.getText().toString().equals("")) {
                    etTripName.setError("give name for Trip");
                }else{
                    if (selectedCity==-1){
                        Toast.makeText(AddTrip.this, "Select from search", Toast.LENGTH_SHORT).show();
                    }else {
                        new getGeoLocation().execute(placeIds.get(selectedCity));
                    }

                }
            }
        });
    }

    class getFirstApi extends AsyncTask<String ,Void,String > {

        @Override
        protected String doInBackground(String... str) {
            String url="https://maps.googleapis.com/maps/api/place/autocomplete/json?" +
                    "key="+apiKey+"&" +
                    "types=(cities)&"+
                    "input="+str[0];//city=str[0]
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(url)
                    .build();
            try {
                Response response = client.newCall(request).execute();
                Log.d(TAG, "doInBackground: getFirstApi: response code:"+response.code());
                return response.body().string();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return "";
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (s.equals(""))
            {
                Toast.makeText(AddTrip.this, "first api return \"\"", Toast.LENGTH_SHORT).show();
            }else{
                parseJsonForGettingCities(s);
                Log.d(TAG, "onPostExecute: first city:"+nameOfCityWithState.get(0));
                Log.d(TAG, "onPostExecute: first place id:"+placeIds.get(0));
                //new MainActivity.GetGeoLocation().execute(placeIds.get(0));
                adapter.notifyDataSetChanged();
            }
        }
    }

    private void parseJsonForGettingCities(String s) {
        try {
            JSONObject root = new JSONObject(s);
            String status = root.getString("status");
            Toast.makeText(this, status, Toast.LENGTH_SHORT).show();
            JSONArray predictions = root.getJSONArray("predictions");
            for (int i=0 ; i<predictions.length();i++){
                JSONObject obj = (JSONObject) predictions.get(i);
                String ctiyWithState = obj.getString("description");
                //triming country
                ctiyWithState=ctiyWithState.substring(0,ctiyWithState.lastIndexOf(","));
                nameOfCityWithState.add(ctiyWithState);
                String placeId = obj.getString("place_id");
                placeIds.add(placeId);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    class getGeoLocation extends AsyncTask<String , Void,String >{

        @Override
        protected String doInBackground(String... str) {
            String url="https://maps.googleapis.com/maps/api/place/details/json?" +
                    "key="+apiKey+"&" +
                    "placeid="+str[0];//place_id=str[0]
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(url)
                    .build();
            try {
                Response response = client.newCall(request).execute();
                Log.d(TAG, "doInBackground: GetGeoLocation: response code:"+response.code());
                return response.body().string();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return "";
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (s.equals(""))
            {
                Toast.makeText(AddTrip.this, "first api return \"\"", Toast.LENGTH_SHORT).show();
            }else{
                parseJsonForGettingLatLag(s);
                Log.d(TAG, "onPostExecute: GetGeoLocation lat:"+lat+" lng:"+lng);
                //saving into firebase
                saveIntoFireStore();

            }
        }
    }

    private void saveIntoFireStore() {
        Map<String, Object> map = new HashMap<>();
        map.put("TripName",etTripName.getText().toString());
        map.put("CityName",etCityName.getText().toString());
        map.put("lat",lat);
        map.put("lng",lng);
        map.put("place_id",placeIds.get(selectedCity));

        db.collection("Trips")
                .add(map)
                .addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentReference> task) {
                        if (task.isSuccessful()){
                            Log.d(TAG, "onComplete: adding trip to firestore succeful");
                            finish();
                        }else{
                            Log.d(TAG, "onComplete: adding trip to firestore failed");
                        }
                    }
                });
    }

    private void parseJsonForGettingLatLag(String s) {
        try {
            JSONObject root = new JSONObject(s);
            String status = root.getString("status");
            Toast.makeText(this, status, Toast.LENGTH_SHORT).show();
            JSONObject obj =  root.getJSONObject("result");
            JSONObject geometry = obj.getJSONObject("geometry");
            JSONObject location = geometry.getJSONObject("location");
            lat = location.getDouble("lat");
            lng = location.getDouble("lng");
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
