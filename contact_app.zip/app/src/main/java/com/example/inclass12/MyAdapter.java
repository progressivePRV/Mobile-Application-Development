package com.example.inclass12;

import android.annotation.SuppressLint;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder>{

    ToCommunicateWithAcitivity mctx;
    ArrayList<ContactsObj> contacts = new ArrayList<>();
    static String TAG = "chupbes";

    public MyAdapter(ArrayList<ContactsObj> conts,Contacts ctx) {
        super();
        this.contacts=conts;
        this.mctx= (ToCommunicateWithAcitivity) ctx;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LinearLayout rvLayout = (LinearLayout) LayoutInflater.from(parent.getContext()).inflate(R.layout.rv_layout,parent,false);
        ViewHolder viewHolder = new ViewHolder(rvLayout);
        return viewHolder;
    }

    @SuppressLint("ResourceType")
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        Log.d(TAG, "onBindViewHolder: before =>"+contacts.get(position).toString());
        holder.tvName.setText(contacts.get(position).name);
        holder.tvEmail.setText(contacts.get(position).email);
        holder.tvPhone.setText(contacts.get(position).phone);
        if (!contacts.get(position).photoUrl.equals("Nope")){
            Picasso.get().load(contacts.get(position).photoUrl).into(holder.ivPhoto);
        }else{
            holder.ivPhoto.setImageResource(17301559);
        }
        holder.cons.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                mctx.deleteContact(position);
                return false;
            }
        });
    }

    @Override
    public int getItemCount() {
        return contacts.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName,tvPhone,tvEmail;
        ImageView ivPhoto;
        ConstraintLayout cons;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvEmail=itemView.findViewById(R.id.tv_email_inRvLayout);
            ivPhoto=itemView.findViewById(R.id.iv_photo_inRvLayout);
            tvPhone=itemView.findViewById(R.id.tv_number_inRvLayout);
            tvName=itemView.findViewById(R.id.tv_name_inRvLayout);
            cons=itemView.findViewById(R.id.con_inRvLayout);
        }
    }

    interface ToCommunicateWithAcitivity{
        void deleteContact(int postion);
    }
}
