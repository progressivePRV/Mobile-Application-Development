package com.example.inclass10;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class Display extends Fragment {

    ToFinishDisplayFrag mcontext;

    String  name;
    String gender;
    public Display(String name,String gender) {
        // Required empty public constructor
        this.name = name;
        this.gender = gender;
    }

    ImageView ivAvatar;
    TextView tvName,tvGender;
    Button btnEdit;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mcontext = (ToFinishDisplayFrag) getActivity();
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_display, container, false);

        getActivity().setTitle("Display Profile");

        ivAvatar = v.findViewById(R.id.iv_avatar_inDisplayFrag);
        tvGender = v.findViewById(R.id.tv_gender_inDisplayFrag);
        tvName = v.findViewById(R.id.tv_name_inDisplayFrag);
        btnEdit = v.findViewById(R.id.btn_edit_inDisplayFrag);

        tvName.setText(name);
        tvGender.setText(gender);

        if (gender.equals("female")) ivAvatar.setImageResource(R.drawable.female);
        else if(gender.equals("male")) ivAvatar.setImageResource(R.drawable.male);

        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mcontext.finishLatestFrag();
            }
        });

        return v;
    }

    public interface ToFinishDisplayFrag {
        void finishLatestFrag();
    }
}
