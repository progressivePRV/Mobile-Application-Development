package com.example.inclass06;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    int noOfItems=0;
    ProgressBar pb1;
    ArrayList<News> USnews = new ArrayList<>();
    Button btnSelect;
    ImageButton ibNext,ibPrev;
    ImageView ivurlToImage;
    TextView tvCategory,tvTitle,tvPublishedAt,tvDescription,tvOutOfOn;
    public static String TAG = "demoTAG";
    String baseURL = "http://newsapi.org/v2/top-headlines";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        pb1 = findViewById(R.id.pb1);
        tvOutOfOn = findViewById(R.id.tv_outOfNo);
        ibNext = findViewById(R.id.ib_next);
        ibPrev = findViewById(R.id.ib_prev);
        ivurlToImage = findViewById(R.id.iv_urlToImage);
        tvCategory = findViewById(R.id.tv_category);
        tvTitle = findViewById(R.id.tv_title);
        tvPublishedAt = findViewById(R.id.tv_publishedAt);
        tvDescription = findViewById(R.id.tv_description);
        ibPrev.setEnabled(false);
        ibNext.setEnabled(false);

        AlertDialog.Builder builder =  new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Choose category");
        final String[] categories = {"business", "entertainment", "general", "health", "science", "sports", "technology"};
        builder.setItems(categories, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                tvCategory.setText(categories[which]);
                if (isConnected()){
                    new GetJSONData().execute(categories[which]);
                }else {
                    Toast.makeText(MainActivity.this, "No Internet", Toast.LENGTH_SHORT).show();
                }

            }
        });
        final AlertDialog alrt = builder.create();

        findViewById(R.id.btn_Select).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alrt.show();
            }
        });

        ibNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (noOfItems==USnews.size()-1){
                    noOfItems=0;
                }else {
                    noOfItems++;
                }
                showData(noOfItems);
            }
        });

        ibPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (noOfItems==0){
                    noOfItems=USnews.size()-1;
                }else {
                    noOfItems--;
                }
                showData(noOfItems);
            }
        });


    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }

    class GetJSONData extends AsyncTask<String ,Void, ArrayList<News>>{

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pb1.setVisibility(View.VISIBLE);
            noOfItems=0;
            tvDescription.setVisibility(View.INVISIBLE);
            tvTitle.setVisibility(View.INVISIBLE);
            tvPublishedAt.setVisibility(View.INVISIBLE);
            ivurlToImage.setVisibility(View.INVISIBLE);
            ibPrev.setEnabled(false);
            ibNext.setEnabled(false);
        }

        @Override
        protected ArrayList<News> doInBackground(String... strings) {
            HttpURLConnection connection = null;
            String category = strings[0];
            ArrayList<News> news = new ArrayList<>();
            try {
                String url = baseURL+"?"+"country=us&"+"apiKey="+getResources().getString(R.string.news_api_key)
                        +"&"+"category="+URLEncoder.encode(category,"UTF-8");
                URL urlB =  new URL(url);
                connection = (HttpURLConnection) urlB.openConnection();

                connection.connect();

                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    String json = IOUtils.toString(connection.getInputStream(), "UTF8");

                    JSONObject root = new JSONObject(json);
                    JSONArray articles = root.getJSONArray("articles");
                    for (int i=0;i<articles.length();i++) {
                        JSONObject articleJson = articles.getJSONObject(i);
                        News newsItem =  new News();
                        newsItem.title = articleJson.getString("title");
                        newsItem.imageURL = articleJson.getString("urlToImage");
                        newsItem.descriptioin = articleJson.getString("description");
                        newsItem.publishedAt = articleJson.getString("publishedAt");
                        news.add(newsItem);
                    }
                }
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return news;
        }

        @Override
        protected void onPostExecute(ArrayList<News> news) {
            super.onPostExecute(news);
            USnews = news;
            pb1.setVisibility(View.INVISIBLE);
            ivurlToImage.setVisibility(View.VISIBLE);
            showData(noOfItems);
            tvDescription.setVisibility(View.VISIBLE);
            tvTitle.setVisibility(View.VISIBLE);
            tvPublishedAt.setVisibility(View.VISIBLE);
            ivurlToImage.setVisibility(View.VISIBLE);
            ibPrev.setEnabled(true);
            ibNext.setEnabled(true);
            if (news.size()==0 || news.size()==1){
                ibPrev.setEnabled(false);
                ibNext.setEnabled(false);
                if(news.size()==0){
                    Toast.makeText(MainActivity.this, "No News Found", Toast.LENGTH_SHORT).show();
                    tvDescription.setVisibility(View.INVISIBLE);
                    tvTitle.setVisibility(View.INVISIBLE);
                    tvPublishedAt.setVisibility(View.INVISIBLE);
                    ivurlToImage.setVisibility(View.INVISIBLE);
                }
            }else{
                ibNext.setClickable(true);
                ibPrev.setClickable(true);
            }
        }
    }

    void showData(int i){
        News news = USnews.get(i);
        tvTitle.setText(news.title);
        tvPublishedAt.setText(news.publishedAt);
        tvDescription.setText(news.descriptioin);
        if (isConnected()){
            Picasso.get().load(news.imageURL).into(ivurlToImage);
        }else{
            ivurlToImage.setVisibility(View.INVISIBLE);
            Toast.makeText(this, "No internet to download Image", Toast.LENGTH_SHORT).show();
        }
        Picasso.get().load(news.imageURL).into(ivurlToImage);
        tvOutOfOn.setText((i+1)+" out of "+USnews.size());
    }
}
