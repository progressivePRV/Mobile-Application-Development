package com.example.inclass12;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class SignUp extends AppCompatActivity {

    EditText etFirstName,etLastName,etEmail,etPassword,etConfirmPass;
    private FirebaseAuth mAuth;
    private static final String TAG = "chupbes";
    private FirebaseFirestore db;
    ProgressBar pb;


    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser currentUser = mAuth.getCurrentUser();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        setTitle("Sign Up");

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        pb=findViewById(R.id.pb_inSignUp);
        etConfirmPass=findViewById(R.id.et_confirm_password_inSignUp);
        etEmail=findViewById(R.id.et_email_inSignUp);
        etFirstName=findViewById(R.id.et_firstName_inSignUp);
        etLastName=findViewById(R.id.et_LastName_inSignUp);
        etPassword=findViewById(R.id.et_password_inSignUp);

        findViewById(R.id.btn_sign_inSignUp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validation()){
                    String email = etEmail.getText().toString();
                    String pass = etPassword.getText().toString();
                    pb.setVisibility(View.VISIBLE);
                    CreateUser(email.trim(),pass);
                }
            }
        });

        findViewById(R.id.btn_cancel_inSignUp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void CreateUser(String email, String password) {
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "createUserWithEmail:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            SaveUser(user.getUid());
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w(TAG, "createUserWithEmail:failure", task.getException());
                            Toast.makeText(SignUp.this, task.getException().getMessage(),
                                    Toast.LENGTH_SHORT).show();
                        }
                        pb.setVisibility(View.INVISIBLE);
                    }
                });
    }

    private void SaveUser(final String uid) {
        pb.setVisibility(View.VISIBLE);
        String firstname = etFirstName.getText().toString();
        String lastname = etLastName.getText().toString();
        Map<String, Object> data = new HashMap<>();
        data.put("FirstName", firstname);
        data.put("LastName", lastname);

        db.collection("Users")
                .document(uid)
                .set(data)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                            Log.d(TAG, "onComplete: usre creatd");
                            Toast.makeText(SignUp.this, "New User Created", Toast.LENGTH_SHORT).show();
                            Intent i = new Intent();
                            i.putExtra("uid",uid);
                            setResult(RESULT_OK,i);
                            finish();
                        }else{
                            Log.d(TAG, "onComplete: signup falied");
                            Toast.makeText(SignUp.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private boolean validation() {
        if (etFirstName.getText().toString().equals("")){
            etFirstName.setError("should not be empty");
            return false;
        }
        if (etLastName.getText().toString().equals("")){
            etLastName.setError("should not be empty");
            return false;
        }
        if (etEmail.getText().toString().equals("")){
            etEmail.setError("should not be empty");
            return false;
        }
        String pass=etPassword.getText().toString();
        if (pass.equals("")){
            etPassword.setError("should not be empty");
            return false;
        }
        String confPass=etConfirmPass.getText().toString();
        if (confPass.equals("")){
            etConfirmPass.setError("should not be empty");
            return false;
        }
        if (!confPass.equals(pass)){
            etConfirmPass.setError("Password and Confirm Password should be same");
            return false;
        }
        return true;
    }


}
