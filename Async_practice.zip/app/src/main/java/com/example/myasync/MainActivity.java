package com.example.myasync;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ProgressBar progressBar;
    private TextView tvMin, tvMax, tvAvg, tvValue,tvSelectComplexity;
    private Button btnCalc;
    private SeekBar seekBar1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("In Class 04");

        progressBar = findViewById(R.id.progressBar1);
        tvMin = findViewById(R.id.tv_min);
        btnCalc = findViewById(R.id.btn1_calc);
        seekBar1 = findViewById(R.id.seekBar1);
        tvMax = findViewById(R.id.tv_max);
        tvAvg = findViewById(R.id.tv_avg);
        tvValue = findViewById(R.id.tv_value);
        tvSelectComplexity = findViewById(R.id.tv_select_complexity);

        seekBar1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int i = seekBar.getProgress();
                tvValue.setText((i + " times"));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        btnCalc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!(seekBar1.getProgress() == 0)) {
                    int complexity = seekBar1.getProgress();
                    new GetNumbers().execute(complexity);
                } else {
                    //Log.d("demo","got in to else");
                    Toast.makeText(MainActivity.this, "Complexity should not be zero", Toast.LENGTH_SHORT).show();
                }
                tvMin.setText("Minimum: ");
                tvMax.setText("Maximum: ");
                tvAvg.setText("Average: ");
            }
        });
    }

    class GetNumbers extends AsyncTask<Integer, Void, ArrayList<Double>> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(progressBar.VISIBLE);
            tvAvg.setVisibility(tvAvg.INVISIBLE);
            tvMax.setVisibility(tvMax.INVISIBLE);
            tvMin.setVisibility(tvMin.INVISIBLE);
            tvValue.setVisibility(tvValue.INVISIBLE);
            seekBar1.setVisibility(seekBar1.INVISIBLE);
            tvSelectComplexity.setVisibility(tvSelectComplexity.INVISIBLE);
            btnCalc.setVisibility(btnCalc.INVISIBLE);
        }

        @Override
        protected ArrayList<Double> doInBackground(Integer... integers) {
            return HeavyWork.getArrayNumbers(integers[0]);
        }

        @Override
        protected void onPostExecute(ArrayList<Double> doubles) {
            progressBar.setVisibility(progressBar.INVISIBLE);
            tvAvg.setVisibility(tvAvg.VISIBLE);
            tvMax.setVisibility(tvMax.VISIBLE);
            tvMin.setVisibility(tvMin.VISIBLE);
            tvValue.setVisibility(tvValue.VISIBLE);
            seekBar1.setVisibility(seekBar1.VISIBLE);
            tvSelectComplexity.setVisibility(tvSelectComplexity.VISIBLE);
            btnCalc.setVisibility(btnCalc.VISIBLE);
            Log.d("demo", "so its not good "+doubles.toString());
            double min=Double.MAX_VALUE;
            double max=Double.MIN_VALUE;
            double avg = 0.0;
            for(double d : doubles){
                avg += d;
                if (d > max) {
                    max = d;
                }
                if (d < min) {
                    min = d;
                }
            }
            tvMin.setText("Minimum: " + min);
            tvMax.setText("Maximum: " + max);
            tvAvg.setText("Average: " + avg/doubles.size());
        }
    }
}
