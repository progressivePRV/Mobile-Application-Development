package com.example.inclass13;

import com.google.android.gms.maps.model.LatLng;

public class Location {
    double latitude, longitude;

    public Location(double latitude, double logitude) {
        this.latitude = latitude;
        this.longitude = logitude;
    }

    @Override
    public String toString() {
        return "Location{" +
                "latitude=" + latitude +
                ", longitude=" + longitude +
                '}';
    }

    public double getLongitude() {
        return longitude;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public LatLng getLatlang(){
        LatLng latLng = new LatLng(latitude,longitude);
        return latLng;
    }
}
