package com.example.inclass12;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.jar.Attributes;

public class CreateNewContact extends AppCompatActivity {

    private static final int REQUEST_IMAGE_CAPTURE = 1;
    boolean isPhotoTaken = false;
    private static final String TAG = "chupbes";
    private FirebaseFirestore db;
    EditText etName, etEmail, etPhone;
    ImageView ivPhoto;
    Bitmap bitmap;
    String uid;
    StorageReference storageRef;
    FirebaseStorage storage;
    String photoUrl,photoName;
    ProgressBar pb;
    Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_new_contact);

        setTitle("Create New Contact");

        if (!isConnected()){
            Toast.makeText(this, "There is NO Internet Connection, Application may not work properly", Toast.LENGTH_LONG).show();
        }

        uid = getIntent().getExtras().getString("uid");
        db = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();
        storageRef = storage.getReference();

        pb = findViewById(R.id.pb_inCreateNewContact);
        ivPhoto = findViewById(R.id.iv_photo_inCreateNewContacts);
        etEmail = findViewById(R.id.et_email_inCreateNewContact);
        etName = findViewById(R.id.et_name_inCreateNewContact);
        etPhone = findViewById(R.id.et_phone_inCreateNewContact);
        btnSubmit=findViewById(R.id.btn_submit_inCreateNewContact);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validation()) {
                    createNewContact();
                }
            }
        });

        ivPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnSubmit.setClickable(false);
                dispatchTakePictureIntent();
            }
        });

    }

    private void createNewContact() {
        String name = etName.getText().toString();
        String email = etEmail.getText().toString();
        String phone = etPhone.getText().toString();
        Map<String, Object> data = new HashMap<>();
        data.put("name", name);
        data.put("email", email);
        data.put("phone", phone);
        if (isPhotoTaken) {
            data.put("photoUrl", photoUrl);
            data.put("photoName", photoName);
        } else {
            data.put("photoUrl", "Nope");
            data.put("photoName", "Nope");
        }

        db.collection("Users")
                .document(uid)
                .collection("Contacts")
                .add(data)
                .addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentReference> task) {
                        if (task.isSuccessful()) {
                            Log.d(TAG, "onComplete: Contact created");
                            Toast.makeText(CreateNewContact.this, "New Contact Created", Toast.LENGTH_SHORT).show();
                            finish();
                        } else {
                            Log.d(TAG, "onComplete: contact creation falied");
                            Toast.makeText(CreateNewContact.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private boolean validation() {
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        if (etName.getText().toString().equals("")) {
            etName.setError("should not be empty");
            return false;
        }
        String email=etEmail.getText().toString();
        if (email.equals("")) {
            etEmail.setError("should not be empty");
            return false;
        }
        if (!email.matches(emailPattern)){
            etEmail.setError("Provide valid email address");
            return false;
        }
        if (etPhone.getText().toString().equals("")) {
            etPhone.setError("should not be empty");
            return false;
        }
        return true;
    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent("android.media.action.IMAGE_CAPTURE");
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            btnSubmit.setClickable(false);
            btnSubmit.setEnabled(false);
            Bundle extras = data.getExtras();
            bitmap = (Bitmap) extras.get("data");
            ivPhoto.setImageBitmap(bitmap);
            isPhotoTaken = true;
            UploadePhoto();
        }
    }

    private void UploadePhoto() {
        pb.setVisibility(View.VISIBLE);
        photoName="Images/"+uid+new Date().getTime()+".jpg";
        final StorageReference imageStorageRef = storageRef.child(photoName);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG,100,baos);
        byte[] data = baos.toByteArray();
        UploadTask uploadTask = imageStorageRef.putBytes(data);
        Task<Uri> urlTask = uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
            @Override
            public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                if (!task.isSuccessful()) {
                    throw task.getException();
                }
                // Continue with the task to get the download URL
                return imageStorageRef.getDownloadUrl();
            }
        }).addOnCompleteListener(new OnCompleteListener<Uri>() {
            @Override
            public void onComplete(@NonNull Task<Uri> task) {
                pb.setVisibility(View.INVISIBLE);
                if (task.isSuccessful()) {
                    Uri downloadUri = task.getResult();
                    Log.d(TAG, "onComplete: IMage Uri:" + downloadUri);
                    photoUrl=downloadUri.toString();
                    Log.d(TAG, "onComplete: photourl="+photoUrl);
                    isPhotoTaken=true;
                } else {
                    // Handle failures
                    // ...
                    Toast.makeText(CreateNewContact.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
                btnSubmit.setEnabled(true);
                btnSubmit.setClickable(true);
            }
        });
    }


    boolean isConnected(){
        ConnectivityManager cm = (ConnectivityManager)this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
        return isConnected;
    }
}
