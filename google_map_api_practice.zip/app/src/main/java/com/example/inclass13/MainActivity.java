package com.example.inclass13;

import androidx.fragment.app.FragmentActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.gson.Gson;

import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends FragmentActivity implements OnMapReadyCallback {

    private static final String TAG = "chupbes";
    private GoogleMap mMap;
    Loctaions loctaions;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo_maps);

        String json =  getJsonFromAssets(this,"trip-1.json");
        Log.d(TAG, "onCreate: json=>"+json);
        getLocationsFromJson(json);

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        LatLngBounds.Builder latlngBuilder =  new LatLngBounds.Builder();

        PolylineOptions polylineOptions =  new PolylineOptions();

        Marker startMarker =mMap.addMarker(new MarkerOptions()
                        .position(loctaions.getPoints().get(0).getLatlang()));
        int lastPos= loctaions.points.size()-1;
        Marker EndMarker =mMap.addMarker(new MarkerOptions()
                .position(loctaions.getPoints().get(lastPos).getLatlang()));

        for (int i=0; i<loctaions.points.size();i++){
            LatLng latLng =loctaions.getPoints().get(i).getLatlang();
            polylineOptions.add(latLng);
            latlngBuilder.include(latLng);
        }

        Polyline polyline = mMap.addPolyline(polylineOptions);

        final LatLngBounds latLngBounds = latlngBuilder.build();

        mMap.setOnMapLoadedCallback(new GoogleMap.OnMapLoadedCallback() {
            @Override
            public void onMapLoaded() {
                mMap.moveCamera(CameraUpdateFactory.newLatLngBounds(latLngBounds,70));
                mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(latLngBounds,70));
            }
        });

    }


    String getJsonFromAssets(Context context, String fileName) {
        String jsonString;
        try {
            InputStream is = context.getAssets().open(fileName);

            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();

            jsonString = new String(buffer, "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }

        return jsonString;
    }

    void getLocationsFromJson(String json){
        Gson gson=  new Gson();
        loctaions = gson.fromJson(json,Loctaions.class);
        Log.d(TAG, "getLocationsFromJson: done:=>");//+loctaions);


    }
}
