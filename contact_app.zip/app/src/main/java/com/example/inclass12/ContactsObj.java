package com.example.inclass12;

public class ContactsObj {
    String name,email,phone,photoUrl,photoName;

    public ContactsObj(String name, String email, String phone, String photoUrl,String photoName) {
        this.name = name;
        this.photoName=photoName;
        this.email = email;
        this.phone = phone;
        this.photoUrl = photoUrl;
    }

    @Override
    public String toString() {
        return "ContactsObj{" +
                "name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", phone='" + phone + '\'' +
                ", photoUrl='" + photoUrl + '\'' +
                ", photoName='" + photoName + '\'' +
                '}';
    }

    public ContactsObj(){

    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getPhotoUrl() {
        return photoUrl;
    }

    public String getPhotoName() {
        return photoName;
    }
}
