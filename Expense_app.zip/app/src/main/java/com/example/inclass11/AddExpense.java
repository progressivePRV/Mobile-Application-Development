package com.example.inclass11;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class AddExpense extends AppCompatActivity {

    private static final String TAG ="chupbes" ;
    private FirebaseFirestore db;

    String category="";
    EditText etAmount,etExpenseName;
    Spinner spinCategory;
    static String[] categories = {"Select Category","Groceries", "Invoice", "Transportation", "Shopping", "Rent", "Trips", "Utilities","Other"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense);

        setTitle("Add Expense");

        db = FirebaseFirestore.getInstance();

        etAmount = findViewById(R.id.et_amount_inEditExpense);
        etExpenseName = findViewById(R.id.et_expense_name_inEditExpense);
        spinCategory = findViewById(R.id.spinner_category_inEditExpense);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinCategory.setAdapter(adapter);
        spinCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position==0){
                    category="";
                }else {
                    category=categories[position];
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        findViewById(R.id.btn_add_expense_inAddExpense).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkValidation()){
                   Expense ex = new Expense(etExpenseName.getText().toString(),Double.valueOf(etAmount.getText().toString()),category);
                    db.collection("Expenses")
                            .add(ex)
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(AddExpense.this, "Expense add failed", Toast.LENGTH_SHORT).show();
                                }
                            })
                            .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                @Override
                                public void onSuccess(DocumentReference documentReference) {
                                    Toast.makeText(AddExpense.this, "Expense Added", Toast.LENGTH_SHORT).show();
                                }
                            });
                    finish();
                }
            }
        });

        findViewById(R.id.btn_cancel_inAddExpense).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    boolean checkValidation(){
        Log.d(TAG, "checkValidation: called");
        if (etExpenseName.getText().toString().equals("")){
            etExpenseName.setError("should not be empty");
            return false;
        }
        if (category.equals("")){
            Toast.makeText(this, "Select a category", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (etAmount.getText().toString().equals("")){
            etAmount.setError("should not be empty");
            return false;
        }else{
            Double d = Double.valueOf(etAmount.getText().toString());

            if (d==0.0){
                etAmount.setError("should not be Zero");
                return false;
            }
        }
        Log.d(TAG, "checkValidation: return true");
        return true;
    }
}
