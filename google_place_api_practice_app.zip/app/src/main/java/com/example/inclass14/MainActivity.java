package com.example.inclass14;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterRvIntrip.toInteractWithTrips {

    String apiKey;
    private static final String TAG = "chupbes";
    RecyclerView rv;
    ArrayList<CityObjInfo> cityObjInfos = new ArrayList<>();
    RecyclerView.Adapter rv_adater;
    RecyclerView.LayoutManager rv_layoutManager;
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("Trips");
        apiKey=getResources().getString(R.string.Apikey);
        Log.d(TAG, "onCreate: trips called");

        rv = findViewById(R.id.rv_inTrips);
        rv.setHasFixedSize(true);
        rv_layoutManager =  new LinearLayoutManager(this);
        rv.setLayoutManager(rv_layoutManager);
        rv_adater = new AdapterRvIntrip(this,cityObjInfos);
        rv.setAdapter(rv_adater);

        db.collection("Trips").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot snapshots, @Nullable FirebaseFirestoreException e) {
                if (e != null) {
                    Log.d(TAG, "listen:error e=", e);
                    return;
                }

                for (DocumentChange dc : snapshots.getDocumentChanges()) {
                    CityObjInfo c = new CityObjInfo();
                    final ArrayList<Place> pls = new ArrayList<>();
                    switch (dc.getType()) {
                        case ADDED:
                            Log.d(TAG, "onEvent: place_id="+dc.getDocument().getId());
                            Log.d(TAG, "New city: " + dc.getDocument().getData());
                            c.doc_ref=dc.getDocument().getId();
                            c.place_id=(String) dc.getDocument().get("place_id");
                            c.CityName = (String) dc.getDocument().get("CityName");
                            c.TripName = (String) dc.getDocument().get("TripName");
                            c.lat = (Double) dc.getDocument().get("lat");
                            c.lng = (Double) dc.getDocument().get("lng");
                            cityObjInfos.add(c);
                            break;
                        case MODIFIED:
                            Log.d(TAG, "Modified city: " + dc.getDocument().getData());
                            break;
                        case REMOVED:
                            Log.d(TAG, "Removed city: " + dc.getDocument().getData());
                            break;
                    }
                }
                rv_adater.notifyDataSetChanged();
            }
        });

        findViewById(R.id.iv_add_inTrips).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,AddTrip.class);
                startActivity(i);
            }
        });

    }

    @Override
    public void StartIntentForAddPlaces(String city_doc_ref, Double lat, Double lng) {
        Intent i = new Intent(this,AddPlaces.class);
        i.putExtra("city_doc_ref",city_doc_ref);
        i.putExtra("lat",lat);
        i.putExtra("lng",lng);
        startActivityForResult(i,100);
    }

    @Override
    public void StartIntentForMap(int x) {
        Intent i = new Intent(this,MapsActivity.class);
        i.putExtra("CityObj",cityObjInfos.get(x));
        startActivity(i);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK){
            Log.d(TAG, "onActivityResult: place added in trip");
        }
    }


}
