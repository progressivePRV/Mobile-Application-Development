package com.example.inclass12;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "chupbes";
    private ImageView ivPhoto;


    private FirebaseAuth mAuth;
    FirebaseFirestore db;
    ProgressBar pb1;
    EditText etEmail,etPassword;
    boolean isTakenPhoto=false;

    @Override
    protected void onStart() {
        super.onStart();
        mAuth = FirebaseAuth.getInstance();
        pb1.setVisibility(View.INVISIBLE);
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser!=null){
            Log.d(TAG, "onStart: current user:"+currentUser.getEmail());
            gotoContacts(currentUser.getUid());
        }else{
            Log.d(TAG, "onStart: not found any user");
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("Login");
        //storage = FirebaseStorage.getInstance();
        //storageRef = storage.getReference();

        if (!isConnected()){
            Toast.makeText(this, "There is NO Internet Connection, Application may not work properly", Toast.LENGTH_LONG).show();
        }

        pb1=findViewById(R.id.pb1_inLogin);
        etEmail=findViewById(R.id.et_email_inLogin);
        etPassword=findViewById(R.id.et_password_inLogin);

        findViewById(R.id.btn_login_inLogin).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validation()){
                    String email = etEmail.getText().toString().trim();
                    String pass = etPassword.getText().toString();
                    pb1.setVisibility(View.VISIBLE);
                    AuthenticateUser(email,pass);
                }
            }
        });

        findViewById(R.id.btn_signup_inLogin).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,SignUp.class);
                startActivityForResult(i,100);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==100 && resultCode==RESULT_OK){
            Intent i = new Intent(MainActivity.this,Contacts.class);
            i.putExtra("uid",data.getExtras().getString("uid"));
            startActivity(i);
            finish();
        }
    }

    private void AuthenticateUser(String email, String password) {
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "signInWithEmail:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            gotoContacts(user.getUid());
                        } else {
                            // If sign in fails, display a message to the user.
                            //Log.w(TAG, "signInWithEmail:failure", task.getException());
                            Toast.makeText(MainActivity.this, "login was not successful",Toast.LENGTH_SHORT).show();
                        }
                        pb1.setVisibility(View.INVISIBLE);
                    }
                });
    }

    void gotoContacts(String uid){
        Intent i = new Intent(MainActivity.this,Contacts.class);
        i.putExtra("uid",uid);
        startActivity(i);
        finish();
    }

    private boolean validation() {
        if(etEmail.getText().toString().equals("")){
            etEmail.setError("this should not be empty");
            return false;
        }
        if (etPassword.getText().toString().equals("")){
            etPassword.setError("this should not be empty");
            return false;
        }
        return true;
    }

    boolean isConnected(){
        ConnectivityManager cm = (ConnectivityManager)this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
        return isConnected;
    }

}
