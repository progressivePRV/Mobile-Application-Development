package com.example.loginapp;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {

    public static InteractWithMainActivity interact;
    Context ctx;
    String TAG="chup1";
    ArrayList<MailClass> mails =  new ArrayList<>();

    public MyAdapter(Context ctx, ArrayList<MailClass> mails) {
        this.ctx = ctx;
        this.mails = mails;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LinearLayout rv_layout = (LinearLayout) LayoutInflater.from(parent.getContext()).inflate(R.layout.rv_for_inbox,parent,false);
        ViewHolder viewHolder =  new ViewHolder(rv_layout);
        return viewHolder;
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        interact = (InteractWithMainActivity)ctx;
        holder.tvSubject.setText(mails.get(position).Subject);
        holder.tvTime.setText(mails.get(position).CreatedAt);
        holder.cl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick:  in RV got Pos="+position);
                interact.openMail(position);
            }
        });
        holder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: in RV called delete");
                interact.deleteItem(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mails.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvSubject,tvTime;
        ImageButton btnDelete;
        ConstraintLayout cl;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cl = itemView.findViewById(R.id.constraintLayoutForRv);
            tvSubject = itemView.findViewById(R.id.tv_subject_inRV);
            tvTime = itemView.findViewById(R.id.tv_time_inRV);
            btnDelete = itemView.findViewById(R.id.ivb_delete_inRV);
        }
    }

    public interface InteractWithMainActivity{
        void deleteItem(int position);
        void openMail(int position);
    }
}
