package com.example.inclass07_2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class TriviaActivity extends AppCompatActivity implements MyAdapter.InteractWithMainActivity {

    public static String intKey="intArrayKey";
    private ArrayList<Questions> globalQuestion;

    private CountDownTimer ct;
    private int trueCount=0;
    private TextView tvQuestionNumber,tvTimer,tvQuestion;
    private RecyclerView rvOptions;
    private ImageView ivPicture;
    private ProgressBar pbForImage;
    private int counter=0;
    RecyclerView.Adapter rvAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trivia);
        globalQuestion = (ArrayList<Questions>) getIntent().getExtras().getSerializable(MainActivity.dataKey);
        //stats = new int[globalQuestion.size()];


        tvQuestion = findViewById(R.id.tvQuestion);
        tvQuestionNumber =  findViewById(R.id.tvQNumber);
        tvTimer =  findViewById(R.id.tvTimer);
        ivPicture =  findViewById(R.id.ivPicture);
        rvOptions =  findViewById(R.id.rvOPtions);
        rvOptions.setHasFixedSize(true);
        LinearLayoutManager rv_layoutManager = new LinearLayoutManager(this);
        rvOptions.setLayoutManager(rv_layoutManager);
        pbForImage =  findViewById(R.id.pbForPic);


        findViewById(R.id.btnNext).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                counter++;
                Toast.makeText(TriviaActivity.this, ""+counter, Toast.LENGTH_SHORT).show();
                if(counter==globalQuestion.size()){
                    ct.cancel();
                    Intent i  =  new Intent(TriviaActivity.this,Stats.class);
                    i.putExtra(MainActivity.dataKey,globalQuestion);
                    i.putExtra(intKey,trueCount);
                    startActivity(i);
                    TriviaActivity.this.finish();
                }else{
                    ShowQuestion(counter);
                }
            }
        });

        findViewById(R.id.btnQuit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ct.cancel();
                ct.onFinish();
            }
        });

        ct = new CountDownTimer(2*60*1000, 1000) {
            @Override
            public void onTick(long l) {
                long minute = l/1000/60;
                long second = (l - minute*60*1000)/1000;
                //Log.d(TAG, "onTick: "+ minute+ " "+second);
                tvTimer.setText("Time Left "+minute+" : "+second);
            }

            @Override
            public void onFinish() {
                Intent i  =  new Intent(TriviaActivity.this,Stats.class);
                i.putExtra(MainActivity.dataKey,globalQuestion);
                i.putExtra(intKey,trueCount);
                startActivity(i);
                TriviaActivity.this.finish();
            }
        };

        ct.start();
        ShowQuestion(counter);

    }


    void ShowQuestion(int i){
        ivPicture.setVisibility(View.VISIBLE);
        pbForImage.setVisibility(View.VISIBLE);
        Questions q =  globalQuestion.get(i);
        tvQuestionNumber.setText("Q"+(q.id+1));
        tvQuestion.setText(q.txtQue);
        tvTimer.setText("Time Left: X seconds");
        rvAdapter =  new MyAdapter(q.choices,this);
        rvOptions.setAdapter(rvAdapter);
        if(q.ImageUrl!=null){
            Picasso.get().load(q.ImageUrl).into(ivPicture, new Callback() {
                @Override
                public void onSuccess() {
                    pbForImage.setVisibility(View.INVISIBLE);
                }

                @Override
                public void onError(Exception e) {

                }
            });
        }else {
            ivPicture.setVisibility(View.INVISIBLE);
            pbForImage.setVisibility(View.INVISIBLE);
        }

    }

    @Override
    public void detectClick(int position) {
        if((position+1)==globalQuestion.get(counter).ans){
            trueCount++;
        }
        counter++;
        if(counter==globalQuestion.size()){
            Intent i  =  new Intent(TriviaActivity.this,Stats.class);
            i.putExtra(MainActivity.dataKey,globalQuestion);
            i.putExtra(intKey,trueCount);
            startActivity(i);
            this.finish();
        }else{
            ShowQuestion(counter);
        }

    }
}

