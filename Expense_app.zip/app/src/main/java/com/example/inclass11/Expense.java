package com.example.inclass11;

import android.util.Log;

import androidx.annotation.NonNull;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class Expense implements Serializable {

    private static final String TAG ="chupbes";

    String title;
    Double cost;
    String category;
    String date;
//    HashMap<String , Object> hash;

    public Expense() {

    }

    public Expense(String title, Double cost, String category) {
        this.title = title;
        this.cost = cost;
        this.category = category;
        Date dt = new Date();
        SimpleDateFormat Sformat =  new SimpleDateFormat("MM/dd/yyyy");
        Log.d(TAG, "Expense: constructor dt="+Sformat.format(dt));
        this.date=Sformat.format(dt);
    }

    public String getDate() {
        return date;
    }

    public String getTitle() {
        return title;
    }

    public Double getCost() {
        return cost;
    }

    public String getCategory() {
        return category;
    }

    @NonNull
    @Override
    public String toString() {
        return "titile ="+this.title+
                "cost ="+this.cost+
                "category"+this.category+
                "Date"+this.date;
    }

//    HashMap<String , Object> tohashMap(){
//        hash =  new HashMap<>();
//        hash.put("title",this.title);
//        hash.put("category",this.category);
//        hash.put("cost",this.cost);
//        return hash;
//    }
}
