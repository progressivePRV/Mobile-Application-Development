package com.example.inclass14;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

import static com.google.firebase.firestore.DocumentChange.Type.ADDED;

public class AdapterRvIntrip extends RecyclerView.Adapter<AdapterRvIntrip.ViewHolder> implements AdapterRvInRvIntrips.ToInteractWithParentRvInTrips {

    private static final String TAG = "chupbes";
    toInteractWithTrips t;
    Context ctx;
    ArrayList<CityObjInfo> cityObjInfos = new ArrayList<>();
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    public AdapterRvIntrip(MainActivity mainActivity,ArrayList<CityObjInfo> c) {
        super();
        this.ctx = mainActivity;
        this.cityObjInfos = c;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LinearLayout layout = (LinearLayout) LayoutInflater.from(parent.getContext()).inflate(R.layout.rv_in_trips,parent,false);
        // call for firebase
        ViewHolder viewHolder =  new ViewHolder(layout);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {
        t = (toInteractWithTrips) ctx;
        holder.rv_adater = new AdapterRvInRvIntrips(cityObjInfos.get(position).places,this,cityObjInfos.get(position).doc_ref,position);
        holder.rv.setAdapter(holder.rv_adater);
        holder.tvTripName.setText(cityObjInfos.get(position).TripName);
        holder.tvCityName.setText(cityObjInfos.get(position).CityName);
        holder.ivAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t.StartIntentForAddPlaces(cityObjInfos.get(position).doc_ref,cityObjInfos.get(position).lat,cityObjInfos.get(position).lng);
            }
        });
        holder.ivMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t.StartIntentForMap(position);
            }
        });

        db.collection("Trips")
                .document(cityObjInfos.get(position).doc_ref)
                .collection("Places")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot documentSnapshots, @Nullable FirebaseFirestoreException e) {
                        Log.d(TAG, "onEvent: sub event called fro postion ="+position);
                        if (e != null) {
                            Log.d("", "Error : " + e.getMessage());
                        }

                        for (DocumentChange doc : documentSnapshots.getDocumentChanges()) {
                            Log.d(TAG, "onEvent: going for places in for loop");
                            Place p;
                            if (doc.getType() == ADDED) {
                                Log.d(TAG,"adding place"+ doc.getDocument().getId());
                                p = doc.getDocument().toObject(Place.class);
                                if (ValidateBeforeAddingP(cityObjInfos.get(position).places,p)){ //i dont know why every time i add new trip this is also called
                                    cityObjInfos.get(position).places.add(p);                    // and places are added twice
                                }
                            }
                        }
                        holder.rv_adater.notifyDataSetChanged();
                    }
                });
    }

    private boolean ValidateBeforeAddingP(ArrayList<Place> ps,Place p) {
        Log.d(TAG, "ValidateBeforeAddingP: called");
        for (Place pi : ps) {
            if (pi.placeId.equals(p.placeId)){
                return false;
            }
        }
        return true;
    }

    @Override
    public int getItemCount() {
        return cityObjInfos.size();
    }

    @Override
    public void deletePlace(String place_id,String parent_ref_id,int parent_index,int pos) {
        db.collection("Trips")
                .document(parent_ref_id)
                .collection("Places")
                .document(place_id)
                .delete()
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(ctx, "place deleted", Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(ctx, "place is not deleted", Toast.LENGTH_SHORT).show();
                        }

                    }
                });
        cityObjInfos.get(parent_index).places.remove(pos);
        //rv_adater.notifyDataSetChanged();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTripName,tvCityName;
        ImageView ivMap,ivAdd;
        RecyclerView rv;
        RecyclerView.Adapter rv_adater;
        RecyclerView.LayoutManager rv_layoutManager;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvCityName = itemView.findViewById(R.id.tv_cityName_inRvinTrips);
            tvTripName =itemView.findViewById(R.id.tv_tripName_inRvinTrips);
            ivAdd = itemView.findViewById(R.id.iv_add_inRvinTrips);
            ivMap =itemView.findViewById(R.id.iv_map_inRvinTrips);

            rv = itemView.findViewById(R.id.rv_inRvinTrips);
            rv.setHasFixedSize(true);
            rv_layoutManager =  new LinearLayoutManager(ctx);
            rv.setLayoutManager(rv_layoutManager);
        }

    }

    interface toInteractWithTrips {
        void StartIntentForAddPlaces(String pid, Double lat, Double lng);
        void StartIntentForMap(int x);
    }
}
