package com.example.inclass14;

import java.io.Serializable;

public class Place implements Serializable {
    String name;
    Double lat;
    Double lng;
    String icon;
    String placeId;

    public Place() {

    }

    public Place(String name, Double lat, Double lng, String icon, String placeId) {
        this.name = name;
        this.lat = lat;
        this.lng = lng;
        this.icon = icon;
        this.placeId = placeId;
    }

    @Override
    public String toString() {
        return "Place{" +
                "name='" + name + '\'' +
                ", lat=" + lat +
                ", lng=" + lng +
                ", icon='" + icon + '\'' +
                ", placeId='" + placeId + '\'' +
                '}';
    }

    public String getName() {
        return name;
    }

    public Double getLat() {
        return lat;
    }

    public Double getLng() {
        return lng;
    }

    public String getIcon() {
        return icon;
    }

    public String getPlaceId() {
        return placeId;
    }
}
