package com.example.mybmiapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;


public class MainActivity extends AppCompatActivity {

    private EditText et_weight,et_height_feet,et_height_inches;

    private TextView tv_result,tv_verdict;

    double weight = 0.0;
    int feet=0,inches=0;

    private Button button_calculate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_weight = findViewById(R.id.et_weight);
        et_height_feet = findViewById(R.id.et_height_feet);
        et_height_inches = findViewById(R.id.et_height_inches);

        tv_result = findViewById(R.id.tv_result);
        tv_verdict = findViewById(R.id.tv_verdict);

        button_calculate = findViewById(R.id.button_calculate);

        button_calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int temp; //temporary variable for function letsDoIt
                String weight_text = et_weight.getText().toString();
                String feet_text = et_height_feet.getText().toString();
                String inches_text=et_height_inches.getText().toString();

                temp=letsDoIt(weight_text,feet_text,inches_text);

                //BMI = (Weight in Pounds / (Height in inches x Height in inches)) x 703
                //1 foot = 12 inches
            }
        });

    }

    int letsDoIt(String weight_text,String feet_text,String inches_text){
        if(weight_text.equals("") || weight_text.equals("0"))
        {
            et_weight.setError("Can't be Empty or zero !!");
            return 1;
        }else{
            weight = Double.parseDouble(weight_text);
        }
        if(feet_text.equals("") && inches_text.equals(""))
        {
            et_height_feet.setError("Can't be Empty!!");
            et_height_inches.setError("Can't be Empty!!");
            return 1;
        }else{
            if(feet_text.equals("0") && inches_text.equals("")){
                et_height_feet.setError("Can't have zero height!!");
                return 1;
            }
            if(feet_text.equals("") && inches_text.equals("0")){
                et_height_inches.setError("Can't have zero height!!");
                return 1;
            }
            if(feet_text.equals("0") && inches_text.equals("0")){
                et_height_feet.setError("feet and Inches both can't be zero");
                et_height_inches.setError("feet and Inches both can't be zero");
                return 1;
            }
            inches=0;
            if(!inches_text.equals("")){
                inches = Integer.parseInt(inches_text);
            }if(!feet_text.equals("")){
                feet = Integer.parseInt(feet_text);
            }
            inches = inches+feet*12;
            double bmi = weight/(inches*inches)*703;
            DecimalFormat DF1 = new DecimalFormat("###.00");

            tv_result.setText("Your BMI: "+DF1.format(bmi));

            if(bmi<18.5){
                tv_verdict.setText("You are Underweight");
                tv_verdict.setTextColor(Color.rgb(155,0,0));
            }else if(bmi>18.5 && bmi<=24.9){
                tv_verdict.setText("You have Normal weight");
                tv_verdict.setTextColor(Color.rgb(0,200,0));
            }else if(bmi>24.9 && bmi<=29.9){
                tv_verdict.setText("You are Overweight");
                tv_verdict.setTextColor(Color.rgb(155,0,0));
            }else if(bmi>29.9){
                tv_verdict.setText("You are Obese!!!");
                tv_verdict.setTextSize(20);
                tv_verdict.setTextColor(Color.rgb(255,0,0));
            }
            Toast.makeText(this, "BMI Calculated", Toast.LENGTH_SHORT).show();
        }
        return 0;
    }
}
