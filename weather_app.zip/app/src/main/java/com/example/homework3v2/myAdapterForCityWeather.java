package com.example.homework3v2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Date;

public class myAdapterForCityWeather extends RecyclerView.Adapter<myAdapterForCityWeather.ViewHolder> {

    City_weather.Day[] days =  new City_weather.Day[5];
    public static toInteractWithActivity interact;

    public myAdapterForCityWeather(City_weather.Day[] days,City_weather city_weather) {
        this.days = days;
        this.interact=city_weather;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LinearLayout rvLL = (LinearLayout) LayoutInflater.from(parent.getContext()).inflate(R.layout.rv_in_city_weather,parent,false);
        ViewHolder v = new ViewHolder(rvLL);
        return v;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        City_weather.Day d = days[position];
        Date date = new Date((d.epochForTime)*1000);
        SimpleDateFormat sdf = new SimpleDateFormat(" dd MMM''yy");
        holder.tvDayDate.setText(sdf.format(date));
        holder.cl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                interact.selectDay(position);
            }
        });
        Picasso.get().load("http://developer.accuweather.com/sites/default/files/"+d.dayIcon+"-s.png").into(holder.ivDayIconInRv);
    }

    @Override
    public int getItemCount() {
        return days.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivDayIconInRv;
        TextView tvDayDate;
        ConstraintLayout cl;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cl = itemView.findViewById(R.id.cl_in_rv_in_cityWeather);
            ivDayIconInRv = itemView.findViewById(R.id.iv_day_icon_in_rv);
            tvDayDate =  itemView.findViewById(R.id.tv_day_text);
        }
    }

    public interface toInteractWithActivity {
        void selectDay(int pos);
    }
}
