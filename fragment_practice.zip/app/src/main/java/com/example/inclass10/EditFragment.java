package com.example.inclass10;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class EditFragment extends Fragment {

    ToAvatarFromEdit mContext;

    public EditFragment() {
        // Required empty public constructor
    }

    private EditText etFirstName,etLastName;
    private Button btnSave;
    private ImageView ivAvatar;
    private String  gender="",name;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = (ToAvatarFromEdit) getActivity();
    }

    public void SetAvatar(String gender){
        this.gender = gender;
        if (gender.equals("female")) ivAvatar.setImageResource(R.drawable.female);
        else if(gender.equals("male")) ivAvatar.setImageResource(R.drawable.male);
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_edit, container, false);

        getActivity().setTitle("My profile");

        btnSave = view.findViewById(R.id.btn_save);
        ivAvatar = view.findViewById(R.id.iv_InEditFrag);
        etFirstName = view.findViewById(R.id.et_firstName_inEditFrag);
        etLastName = view.findViewById(R.id.et_lastName_inEditFrag);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = etFirstName.getText().toString() +" "+ etLastName.getText().toString();
                if (etFirstName.getText().toString().equals("")){
                    etFirstName.setError("this should not be empty");
                }else{
                    if (etLastName.getText().toString().equals("")){
                        etLastName.setError("this should not be empty");
                    }else{
                        if (gender.equals("")){
                            Toast.makeText(getActivity(), "Select avatar first", Toast.LENGTH_SHORT).show();
                        }else{
                            mContext.startDisplayFrag(name,gender);
                        }
                    }
                }
            }
        });

        ivAvatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContext.startSelectAvatar();
            }
        });
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (gender.equals("female")) ivAvatar.setImageResource(R.drawable.female);
        else if(gender.equals("male"))ivAvatar.setImageResource(R.drawable.male);
    }

    public interface ToAvatarFromEdit{
        void startSelectAvatar();
        void startDisplayFrag(String name,String gender);
    }
}
