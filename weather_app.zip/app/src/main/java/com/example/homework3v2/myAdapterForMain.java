package com.example.homework3v2;

import android.annotation.SuppressLint;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.text.ParseException;
import java.util.ArrayList;

public class myAdapterForMain extends RecyclerView.Adapter<myAdapterForMain.ViewHolder> {

    ArrayList<City> cities = new ArrayList<>();
    static toInteractWithMain interact;

    public myAdapterForMain(ArrayList<City> cities,MainActivity mainActivity) {
        this.cities = cities;
        this.interact = mainActivity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LinearLayout ll = (LinearLayout) LayoutInflater.from(parent.getContext()).inflate(R.layout.rv_for_main,parent,false);
        ViewHolder v =  new ViewHolder(ll);
        return v;
    }

    @SuppressLint("ResourceType")
    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {
        final City c =cities.get(position);
        holder.tvcityAndCountry.setText(c.cityName+","+c.country);
        holder.tvtemperature.setText(c.temperature);
        try {
            holder.tvUpdated.setText(c.updated());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        holder.cl.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                interact.delete(position);
                return false;
            }
        });
        if (c.favorite){
            holder.ivStar.setImageResource(17301516);
        }else{
            holder.ivStar.setImageResource(17301515);
        }
        holder.ivStar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //holder.ivStar
                if (c.favorite){
                    interact.changeFavorite(position,false);
                }else{
                    interact.changeFavorite(position,true);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return cities.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView tvcityAndCountry,tvtemperature,tvUpdated;
        ImageView ivStar;
        ConstraintLayout cl;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cl = itemView.findViewById(R.id.cl_in_rv_inMain);
            tvcityAndCountry = itemView.findViewById(R.id.tv_cityandCountry_in_rv_inMain);
            tvtemperature = itemView.findViewById(R.id.tv_temperature_in_rv_inMain);
            tvUpdated = itemView.findViewById(R.id.tv_updated_in_rv_inMain);
            ivStar = itemView.findViewById(R.id.iv_star);
        }
    }

    public interface toInteractWithMain {
        void delete(int pos);
        void changeFavorite(int pos,boolean b);
    }
}
