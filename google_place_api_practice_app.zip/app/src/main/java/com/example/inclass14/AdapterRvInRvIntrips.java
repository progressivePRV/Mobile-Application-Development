package com.example.inclass14;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class AdapterRvInRvIntrips extends RecyclerView.Adapter<AdapterRvInRvIntrips.ViewHolder> {

    AdapterRvIntrip ctx;
    ArrayList<Place> places =  new ArrayList<>();
    String parent_ref_id;
    int parent_index;
    public AdapterRvInRvIntrips(ArrayList<Place> arrayList, AdapterRvIntrip adapter,String parent_ref_id,int parent_index) {
        super();
        this.places=arrayList;
        this.ctx = adapter;
        this.parent_ref_id = parent_ref_id;
        this.parent_index = parent_index;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LinearLayout rv_layout = (LinearLayout) LayoutInflater.from(parent.getContext()).inflate(R.layout.rv_layout_for_rv_in_trips,parent,false);
        ViewHolder viewHolder = new ViewHolder(rv_layout);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        holder.ivDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ctx.deletePlace(places.get(position).placeId,parent_ref_id,parent_index,position);
            }
        });
        holder.tvPlaces.setText(places.get(position).name);
        Picasso.get().load(places.get(position).icon).into(holder.ivIcon);
    }

    @Override
    public int getItemCount() {
        return places.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvPlaces;
        ImageView ivIcon,ivDelete;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvPlaces = itemView.findViewById(R.id.tv_tripName_inRvInRVintrips);
            ivDelete = itemView.findViewById(R.id.iv_delete_inRvIRVintrips);
            ivIcon = itemView.findViewById(R.id.iv_icon_inRvInRVintrips);
        }
    }

    interface ToInteractWithParentRvInTrips{
        void deletePlace(String place_id,String parent_place_id,int parent_index,int place_positioin);
    }
}
