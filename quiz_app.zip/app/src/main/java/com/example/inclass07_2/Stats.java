package com.example.inclass07_2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SearchRecentSuggestionsProvider;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Stats extends AppCompatActivity {

    ArrayList<Questions> globalQuestion;
    //int[] stats;
    TextView tvPercCorAns;
    ProgressBar pbCorrectBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);
        int correctAns = getIntent().getExtras().getInt(TriviaActivity.intKey);
        globalQuestion = (ArrayList<Questions>) getIntent().getExtras().getSerializable(MainActivity.dataKey);
        Log.d("trythis", "correct ans="+correctAns);
        Log.d("trythis","ans for 13 is = "+globalQuestion.get(13).ans);
        int perc = correctAns*100;
        Log.d("trythis", "perc brfore devide= "+perc);
        perc=perc/globalQuestion.size();
        Log.d("trythis", "perc after devide= "+perc);
      //  Log.d("trythis", "stats.lrn= "+stats.length);
        //Log.d("trythis", "perc = "+correctAns*100/stats.length);
        tvPercCorAns = findViewById(R.id.tvPercentageCorrect);
        pbCorrectBar = findViewById(R.id.pbhCorrect);
        pbCorrectBar.setProgress(perc);
        tvPercCorAns.setText(perc+"%");
        findViewById(R.id.btnTryAgain).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =  new Intent(Stats.this, TriviaActivity.class);
                i.putExtra(MainActivity.dataKey,globalQuestion);
                startActivity(i);
                Stats.this.finish();
            }
        });

        findViewById(R.id.btnQuitInTriviaStats).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Stats.this.finish();
            }
        });
    }
}
