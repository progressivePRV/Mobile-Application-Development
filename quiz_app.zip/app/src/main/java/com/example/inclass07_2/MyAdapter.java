package com.example.inclass07_2;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder>{

    public static InteractWithMainActivity interact;
    Context ctx;

    String[] options;

    public MyAdapter(String[] choices,TriviaActivity triviaActivity) {
        this.options = choices;
        this.ctx = triviaActivity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LinearLayout rvLayoutOptions = (LinearLayout) LayoutInflater.from(parent.getContext()).inflate(
                R.layout.options,parent, false);
        ViewHolder viewHolder =  new ViewHolder(rvLayoutOptions);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        holder.tvoption.setText(options[position]);
        interact = (InteractWithMainActivity) ctx;
        holder.tvoption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.setBackgroundColor(Color.rgb(255,255,255));
                interact.detectClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return options.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView tvoption;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvoption = itemView.findViewById(R.id.tvOption);
        }
    }

    public interface InteractWithMainActivity{
        void detectClick(int position);
    }
}
